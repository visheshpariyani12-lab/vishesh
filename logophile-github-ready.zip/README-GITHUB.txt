LOGOPHILE — GitHub Pages package

Files:
- index.html — main portfolio page
- assets/ — portfolio images
- whitepapers/ — original whitepaper PDFs
- academic/ — original academic DOCX samples
- .nojekyll — keeps this static site from being processed by Jekyll

Upload ALL files and folders in this package to the ROOT of the GitHub repository.
GitHub Pages should use: main branch + /(root).
